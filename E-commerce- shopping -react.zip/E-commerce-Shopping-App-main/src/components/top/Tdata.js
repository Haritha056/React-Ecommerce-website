const Tdata = [
  {
    cover: "./images/top/slide-1.png",
    para: "Good Seller!",
    desc: "I am very happy with the services provided,it is very helpful, starting from the insight that the company gave from the start.",
    author:"Anna Saraspova",
    note: "Your Beloved Buyer",
  },
  {
    cover: "./images/top/slide-1.png",
    para: "Good Seller!",
    desc: "I am very happy with the services provided,it is very helpful, starting from the insight that the company gave from the start.",
    author:"Anna Saraspova",
    note: "Your Beloved Buyer",
  },
  {
    cover: "./images/top/slide-1.png",
    para: "Good Seller!",
    desc: "I am very happy with the services provided,it is very helpful, starting from the insight that the company gave from the start.",
    author:"Anna Saraspova",
    note: "Your Beloved Buyer",
  },
  {
    cover: "./images/top/slide-1.png",
    para: "Good Seller!",
    desc: "I am very happy with the services provided,it is very helpful, starting from the insight that the company gave from the start.",
    author:"Anna Saraspova",
    note: "Your Beloved Buyer",
  },
  {
    cover: "./images/top/slide-1.png",
    para: "Good Seller!",
    desc: "I am very happy with the services provided,it is very helpful, starting from the insight that the company gave from the start.",
    author:"Anna Saraspova",
    note: "Your Beloved Buyer",
  },
]

export default Tdata
