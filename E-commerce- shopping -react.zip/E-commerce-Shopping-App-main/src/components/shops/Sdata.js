const Sdata = {
  shopItems: [
    {
      id: 7,
      cover: "./images/shops/shops-01.png",
      name: "Frock",
      
      
    },
    {
      id: 8,
      cover: "./images/shops/shops-02.png",
      name: "Tops",
      
    },
    {
      id: 9,
      cover: "./images/shops/shops-03.png",
      name: "Peach dress",
      
    },
    {
      id: 10,
      cover: "./images/shops/shops-04.png",
      name: "Red shirt",
      
    },
    {
      id: 11,
      cover: "./images/shops/shops-05.png",
      name: "Red skirt",
      
    },
    {
      id: 12,
      cover: "./images/shops/shops-07.png",
      name: "white coat",
      
    },
    {
      id: 13,
      cover: "./images/shops/shops-08.png",
      name: "Tracksuit",
     
    },
    {
      id: 14,
      cover: "./images/shops/shops-01.png",
      name: "Frock",
      
    },
    {
      id: 15,
      cover: "./images/shops/shops-10.png",
      name: "Silver Cap",
      
    },
  ],
}
export default Sdata
