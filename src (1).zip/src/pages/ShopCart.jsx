import React, { useState } from "react"

const ShopCart = ({ shopItems, addToCart }) => {
  const [count, setCount] = useState(0)
  const increment = () => {
    setCount(count + 1)
  }

  return (
    <>
      {shopItems.map((shopItems, index) => {
        return (
          <><div className='box'>
            <div className='product mtop'>
              <div className='img'>

                <img src={shopItems.cover} alt='' />

              </div>
              <div className='product-details'>
                <h3>{shopItems.name}</h3>
                <h1>{shopItems.name}</h1>
                <div className='price'>
                
                  <button><i className='fa fa-arrow-circle-right'></i></button>
                 
                  {/* <button onClick={() => addToCart(shopItems)}>
                  <i className='fa fa-plus'></i>
                  </button> */}
                </div>
              </div>
            </div>
          </div></>
        )
      })}
    </>
  )
}

export default ShopCart
