import React from "react"
import Home from "../components/MainPage/Home"
import Shop from "../components/shops/Shop"
import FlashDeals from "../components/flashDeals/FlashDeals"
import TopCate from "../components/top/TopCate"
import NewArrivals from "../components/newarrivals/NewArrivals"
import Discount from "../components/discount/Discount" 
import Annocument from "../components/annocument/Annocument"
import Wrapper from "../components/wrapper/Wrapper"
import Come from "../components/samle/come"
 import Items from "./Items"


const Pages = ({ productItems, addToCart, CartItem, shopItems }) => {
  return (
    <>
      <Home CartItem={CartItem} />

      <Shop shopItems={shopItems} addToCart={addToCart} />
      <FlashDeals productItems={productItems} addToCart={addToCart} />
      <TopCate />
      <NewArrivals />
      <Discount />
      <Items />
      <Annocument />
      <Come/>
      <Wrapper />
      
      </>
  )
}

export default Pages
