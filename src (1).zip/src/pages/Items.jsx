import React from "react"
import Come from "../components/samle/come"
import "./style.css"

const Items = () => {
  return (
    <>
      
          <Come />

          
          
          
          
          
    </>
  )
}

export default Items