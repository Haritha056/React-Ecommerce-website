const Sdata = {
  shopItems: [
    {
      id: 7,
      cover: "./images/shops/shops-1.png",
      name: "Mapple Earphones",
      
      
    },
    {
      id: 8,
      cover: "./images/shops/shops-2.png",
      name: "Vivo android one",
      
    },
    {
      id: 9,
      cover: "./images/shops/shops-3.png",
      name: "Sony Light",
      
    },
    {
      id: 10,
      cover: "./images/shops/shops-4.png",
      name: "Iphone",
      
    },
    {
      id: 11,
      cover: "./images/shops/shops-5.png",
      name: "Ceats wireless earphone",
      
    },
    {
      id: 12,
      cover: "./images/shops/shops-7.png",
      name: "Redimi Phone",
      
    },
    {
      id: 13,
      cover: "./images/shops/shops-8.png",
      name: "Xeats Bluetooth",
     
    },
    {
      id: 14,
      cover: "./images/shops/shops-9.png",
      name: "Airpod",
      
    },
    {
      id: 15,
      cover: "./images/shops/shops-10.png",
      name: "Silver Cap",
      
    },
  ],
}
export default Sdata
