import React from "react"


const Come = () => {
  return (
    
      <section className='come'>
        <div className='container d_flex'>
          <h1>hello</h1>
          <Come />
          </div>
      </section>
    
  )
}

export default Come