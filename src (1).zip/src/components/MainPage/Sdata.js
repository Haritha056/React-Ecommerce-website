const Sdata = [
  {
    id: 1,
    title: "Your Premium Sound Unplugged!",
    desc: "Get your favorite Products here with fantabulous designs and marvelous fabrics",
    cover: "./images/SlideCard/slide-1.png",
  },
  {
    id: 2,
    title: "Your Premium Sound Unplugged!",
    desc: "Get your favorite Products here with fantabulous designs and marvelous fabrics",
    cover: "./images/SlideCard/slide-2.png",
  },
  {
    id: 3,
    title: "Your Premium Sound Unplugged!",
    desc: "Get your favorite Products here with fantabulous designs and marvelous fabrics",
    cover: "./images/SlideCard/slide-3.png",
  },
  {
    id: 4,
    title: "Your Premium Sound Unplugged!",
    desc: "Get your favorite Products here with fantabulous designs and marvelous fabrics.",
    cover: "./images/SlideCard/slide-4.png",
  },
]
export default Sdata
