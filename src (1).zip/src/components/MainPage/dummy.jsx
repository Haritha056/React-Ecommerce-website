import React from "react"


const Home = () => {
  return (
    
      <section className='home'>
        <div className='container d_flex'>
          <h1>hello</h1>
          </div>
      </section>
    
  )
}

export default Home